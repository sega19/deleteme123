SELECT Students.ID, Students.[Last Name], Students.[First Name], [Student Attendance Extended].status, Count([Student Attendance Extended].[Attendance Date]) AS [Number of Days]
FROM Students INNER JOIN [Student Attendance Extended] ON (Students.ID=[Student Attendance Extended].Student) AND ([Student Attendance Extended].Students.ID=Students.ID)
GROUP BY Students.ID, Students.[Last Name], Students.[First Name], [Student Attendance Extended].status;

